# Phoenix Dark Pink

[![MELPA](https://melpa.org/packages/phoenix-dark-pink-theme-badge.svg)](https://melpa.org/#/phoenix-dark-pink-theme)

This is a port of the Phoenix Dark Pink theme I found through Sublime
Text 2's package control plugin. It's a bit rough, but seems
functional for me.

I will likely update it, focusing on fixing it for Lisp, Elisp,
Clojure, Clojurescript, Javascript, Go, Haskell, Magit, mu4e, Circe,
Rust, C and other modes I find useful (read "spend most of my time in").

## Screenshot

Here's an example of the theme displaying Javascript, Go,
Haskell and Clojure.

<img src="https://raw.github.com/j0ni/phoenix-dark-pink/master/phoenix-dark-pink.png" width="800"/>
